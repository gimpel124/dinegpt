const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

const dataFile = path.join(__dirname, 'data', 'products.json');

function readData() {
  if (!fs.existsSync(dataFile)) {
    return { products: [], categories: [] };
  }
  const raw = fs.readFileSync(dataFile, 'utf8');
  try {
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse data file', e);
    return { products: [], categories: [] };
  }
}

function writeData(data) {
  fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
}

// Get all products
app.get('/products', (req, res) => {
  const data = readData();
  res.json(data.products);
});

// Get all categories
app.get('/categories', (req, res) => {
  const data = readData();
  res.json(data.categories);
});

// Create a product
app.post('/products', (req, res) => {
  const data = readData();
  const product = req.body;

  if (!product.name || !product.price || !product.category) {
    return res.status(400).json({ error: 'name, price and category are required' });
  }

  // Simple ID generation
  const newId = (data.products.length ? Math.max(...data.products.map(p => parseInt(p.id || 0, 10) || 0)) + 1 : 1).toString();
  const newItemNumber = product.itemNumber || `DIS-${String(newId).padStart(3, '0')}`;

  const newProduct = {
    id: newId,
    itemNumber: newItemNumber,
    name: product.name,
    category: product.category,
    price: product.price,
    description: product.description || '',
    image: product.image || ''
  };

  data.products.push(newProduct);
  if (!data.categories.includes(product.category)) {
    data.categories.push(product.category);
  }

  writeData(data);
  res.status(201).json(newProduct);
});

// Update a product
app.put('/products/:id', (req, res) => {
  const data = readData();
  const id = req.params.id;
  const index = data.products.findIndex(p => p.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Product not found' });
  }

  const updated = { ...data.products[index], ...req.body, id };
  data.products[index] = updated;

  if (updated.category && !data.categories.includes(updated.category)) {
    data.categories.push(updated.category);
  }

  writeData(data);
  res.json(updated);
});

// Delete a product
app.delete('/products/:id', (req, res) => {
  const data = readData();
  const id = req.params.id;
  const index = data.products.findIndex(p => p.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Product not found' });
  }

  const removed = data.products.splice(index, 1)[0];
  writeData(data);
  res.json(removed);
});

// Create a category
app.post('/categories', (req, res) => {
  const data = readData();
  const { name } = req.body;

  if (!name) {
    return res.status(400).json({ error: 'Category name is required' });
  }
  if (!data.categories.includes(name)) {
    data.categories.push(name);
    writeData(data);
  }
  res.status(201).json({ name });
});

// Delete a category (does not delete products, just removes from list)
app.delete('/categories/:name', (req, res) => {
  const data = readData();
  const name = req.params.name;

  const index = data.categories.indexOf(name);
  if (index === -1) {
    return res.status(404).json({ error: 'Category not found' });
  }

  data.categories.splice(index, 1);
  writeData(data);
  res.json({ success: true });
});

app.listen(PORT, () => {
  console.log(`Dine In Style API running on http://localhost:${PORT}`);
});
