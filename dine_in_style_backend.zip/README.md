# Dine In Style Backend

Simple Express.js API to manage products and categories for your Dine In Style frontend.

## Install

```bash
npm install
```

## Run in development

```bash
npm run dev
```

This starts the server with nodemon on http://localhost:4000

## Run normally

```bash
npm start
```

## Endpoints

- GET /products
- POST /products
- PUT /products/:id
- DELETE /products/:id

- GET /categories
- POST /categories
- DELETE /categories/:name
```
