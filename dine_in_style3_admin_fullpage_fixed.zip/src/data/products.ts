export interface Product {
  id: string;
  itemNumber: string;
  name: string;
  category: string;
  price: string;
  description: string;
  image: string;
}
