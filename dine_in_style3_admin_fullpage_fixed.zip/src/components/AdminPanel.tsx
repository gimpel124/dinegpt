import React, { useState } from 'react';
import { Product } from '../data/products';
import { X } from 'lucide-react';

interface AdminPanelProps {
  products: Product[];
  categories: string[];
  onClose: () => void;
  onRefresh: () => void;
}

interface ProductFormState {
  id?: string;
  name: string;
  itemNumber: string;
  price: string;
  category: string;
  description: string;
  image: string;
}

const emptyProduct: ProductFormState = {
  name: '',
  itemNumber: '',
  price: '',
  category: '',
  description: '',
  image: '',
};

export const AdminPanel: React.FC<AdminPanelProps> = ({
  products,
  categories,
  onClose,
  onRefresh,
}) => {
  const [productForm, setProductForm] = useState<ProductFormState>(emptyProduct);
  const [newCategory, setNewCategory] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleProductChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setProductForm(prev => ({ ...prev, [name]: value }));
  };

  const handleEditClick = (product: Product) => {
    setProductForm({
      id: product.id,
      name: product.name,
      itemNumber: product.itemNumber,
      price: product.price,
      category: product.category,
      description: product.description,
      image: product.image,
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleResetForm = () => {
    setProductForm(emptyProduct);
    setError(null);
  };

  const saveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setError(null);

    try {
      const method = productForm.id ? 'PUT' : 'POST';
      const url = productForm.id
        ? `http://localhost:4000/products/${productForm.id}`
        : 'http://localhost:4000/products';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productForm),
      });

      if (!res.ok) {
        throw new Error('Failed to save product');
      }

      handleResetForm();
      await onRefresh();
    } catch (err) {
      console.error(err);
      setError('Could not save product. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const deleteProduct = async (id: string) => {
    if (!window.confirm('Delete this product?')) return;

    try {
      const res = await fetch(`http://localhost:4000/products/${id}`, {
        method: 'DELETE',
      });

      if (!res.ok) {
        throw new Error('Failed to delete product');
      }

      await onRefresh();
    } catch (err) {
      console.error(err);
      setError('Could not delete product. Please try again.');
    }
  };

  const addCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategory.trim()) return;

    try {
      const res = await fetch('http://localhost:4000/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newCategory.trim() }),
      });

      if (!res.ok) {
        throw new Error('Failed to add category');
      }

      setNewCategory('');
      await onRefresh();
    } catch (err) {
      console.error(err);
      setError('Could not add category. Please try again.');
    }
  };

  const deleteCategory = async (name: string) => {
    if (!window.confirm('Delete this category from the list?')) return;

    try {
      const res = await fetch(`http://localhost:4000/categories/${encodeURIComponent(name)}`, {
        method: 'DELETE',
      });

      if (!res.ok) {
        throw new Error('Failed to delete category');
      }

      await onRefresh();
    } catch (err) {
      console.error(err);
      setError('Could not delete category. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-30 bg-white overflow-y-auto">
      <div className="max-w-6xl mx-auto px-4 py-8 md:py-10">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl md:text-2xl font-semibold text-[#2C3E50]">
              Admin Panel
            </h2>
            <p className="text-sm text-gray-500">
              Manage products and categories for Dine In Style
            </p>
          </div>
          <button
            onClick={onClose}
            className="inline-flex items-center justify-center rounded-full border border-gray-300 p-2 hover:bg-gray-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="mb-4 rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Product form & list */}
          <div className="lg:col-span-2 space-y-4">
            <div className="rounded-2xl border border-gray-200 p-4 md:p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-[#2C3E50]">
                  {productForm.id ? 'Edit Product' : 'Add New Product'}
                </h3>
                {productForm.id && (
                  <button
                    type="button"
                    onClick={handleResetForm}
                    className="text-xs text-gray-500 hover:text-gray-700"
                  >
                    Clear form
                  </button>
                )}
              </div>

              <form className="space-y-3" onSubmit={saveProduct}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      Product name
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={productForm.name}
                      onChange={handleProductChange}
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#C4A571]"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      Item number
                    </label>
                    <input
                      type="text"
                      name="itemNumber"
                      value={productForm.itemNumber}
                      onChange={handleProductChange}
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#C4A571]"
                      placeholder="DIS-013"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      Price
                    </label>
                    <input
                      type="text"
                      name="price"
                      value={productForm.price}
                      onChange={handleProductChange}
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#C4A571]"
                      placeholder="£49.99"
                      required
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      Category
                    </label>
                    <select
                      name="category"
                      value={productForm.category}
                      onChange={handleProductChange}
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#C4A571]"
                      required
                    >
                      <option value="">Select category</option>
                      {categories.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    name="description"
                    value={productForm.description}
                    onChange={handleProductChange}
                    rows={3}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#C4A571]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    Image URL
                  </label>
                  <input
                    type="url"
                    name="image"
                    value={productForm.image}
                    onChange={handleProductChange}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#C4A571]"
                    placeholder="https://..."
                  />
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="inline-flex items-center justify-center rounded-lg bg-[#2C3E50] px-4 py-2 text-sm font-semibold text-white shadow hover:bg-[#1f2e3b] disabled:opacity-60"
                  >
                    {isSaving
                      ? productForm.id
                        ? 'Saving...'
                        : 'Adding...'
                      : productForm.id
                      ? 'Save changes'
                      : 'Add product'}
                  </button>
                </div>
              </form>
            </div>

            <div className="rounded-2xl border border-gray-200 p-4 md:p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-[#2C3E50]">Existing products</h3>
                <p className="text-xs text-gray-500">
                  Click a product to edit or delete
                </p>
              </div>

              <div className="space-y-2 max-h-64 overflow-y-auto text-sm">
                {products.length === 0 && (
                  <p className="text-gray-500 text-sm">No products yet.</p>
                )}

                {products.map((product) => (
                  <div
                    key={product.id}
                    className="flex items-center justify-between gap-3 rounded-lg border border-gray-200 px-3 py-2 hover:bg-gray-50"
                  >
                    <button
                      type="button"
                      onClick={() => handleEditClick(product)}
                      className="flex-1 text-left"
                    >
                      <div className="font-medium text-[#2C3E50]">
                        {product.name}
                      </div>
                      <div className="text-xs text-gray-500">
                        {product.itemNumber} • {product.category} • {product.price}
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => deleteProduct(product.id)}
                      className="text-xs text-red-600 hover:text-red-700"
                    >
                      Delete
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Categories */}
          <div className="space-y-4">
            <div className="rounded-2xl border border-gray-200 p-4 md:p-5">
              <h3 className="font-semibold text-[#2C3E50] mb-3">Categories</h3>

              <form className="flex gap-2 mb-3" onSubmit={addCategory}>
                <input
                  type="text"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  placeholder="New category name"
                  className="flex-1 rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#C4A571]"
                />
                <button
                  type="submit"
                  className="inline-flex items-center justify-center rounded-lg bg-[#C4A571] px-3 py-2 text-sm font-semibold text-white shadow hover:bg-[#b0935f]"
                >
                  Add
                </button>
              </form>

              <div className="space-y-1 max-h-60 overflow-y-auto text-sm">
                {categories.length === 0 && (
                  <p className="text-gray-500 text-sm">No categories yet.</p>
                )}

                {categories.map((cat) => (
                  <div
                    key={cat}
                    className="flex items-center justify-between gap-2 rounded-lg border border-gray-200 px-3 py-2"
                  >
                    <span>{cat}</span>
                    <button
                      type="button"
                      onClick={() => deleteCategory(cat)}
                      className="text-xs text-red-600 hover:text-red-700"
                    >
                      Delete
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-2xl border border-gray-200 p-4 text-xs text-gray-500 space-y-1">
              <p>Changes are saved to a local JSON file on the server.</p>
              <p>
                After deploying, you&apos;ll want to replace this with a real database
                (for example, PostgreSQL or MongoDB).
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
